
from flask import Flask, render_template, request
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'static'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    video = request.files['video']
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'video.webm')
    video.save(save_path)
    return 'تم حفظ الفيديو بنجاح'

if __name__ == '__main__':
    app.run(debug=True)
